package frc.robot.commands;

public class Constant {

    public static final double AutonomousSpeed = 0;

}
