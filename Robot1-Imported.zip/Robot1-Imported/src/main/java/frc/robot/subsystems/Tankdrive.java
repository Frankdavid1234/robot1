// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;
import com.revrobotics.CANSparkMax;
import com.revrobotics.CANSparkMaxLowLevel.MotorType;
import edu.wpi.first.wpilibj.motorcontrol.MotorControllerGroup;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

public class Tankdrive extends SubsystemBase {
  /** Creates a new Tankdrive. */
  
  /**change the SpeedControllerGroup*/
  

    CANSparkMax leftFront;
    CANSparkMax leftRear;
    CANSparkMax rightRear;
    CANSparkMax rightFront;
    MotorControllerGroup leftmotors;
  MotorControllerGroup rightmotors  ;
  DifferentialDrive drive;
  public Tankdrive()
  {
    leftFront = new CANSparkMax (Constants.LEFT1 , MotorType.kBrushless);
    leftFront.setInverted(false);
    leftRear = new CANSparkMax (Constants.LEFT2,MotorType.kBrushless);
    leftRear.setInverted(false);
    rightRear = new CANSparkMax (Constants.RIGHT1,MotorType.kBrushless);
    rightRear.setInverted(false);
    rightFront = new CANSparkMax (Constants.RIGHT2,MotorType.kBrushless);
    rightFront.setInverted(false);

    leftmotors = new MotorControllerGroup (leftFront,leftRear);
    rightmotors = new MotorControllerGroup (rightFront, rightRear);
    drive = new DifferentialDrive (leftmotors, rightmotors);
  }
   

  @Override
  public void periodic() {
    // This method will be called once per scheduler run
  }
   
  public void   driveWithJoysticks(XboxController controller, double speed)
  {  
    drive.arcadeDrive(controller.getRawAxis(Constants.XboxController_LEFT_Y_AXIS)*speed, controller.getRawAxis(Constants.XboxController_LEFT_X_AXIS)*speed);
  }
 
 public void driveforward(double speed)
 {drive.tankDrive(  speed, speed);}
  public void stop (){
    drive.stopMotor();
  }

  
  
    }

